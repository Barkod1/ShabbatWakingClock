package com.example.shabbatclock;

import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;
import android.widget.TimePicker;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

import java.util.Calendar;

public class TimePickerFragment extends DialogFragment

        implements TimePickerDialog.OnTimeSetListener {
    static String time;
    static Intent serviceIntent;
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the current time as the default values for the picker
        final Calendar c = Calendar.getInstance();
        int hour = c.get(Calendar.HOUR_OF_DAY);
        int minute = c.get(Calendar.MINUTE);

        // Create a new instance of TimePickerDialog and return it
        return new TimePickerDialog(getActivity(), this, hour, minute,
                DateFormat.is24HourFormat(getActivity()));
    }

    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        Log.d("time", String.valueOf(hourOfDay)+":" + minute );
        String  hour = String.valueOf(hourOfDay);
        String  min = String.valueOf(minute);
        if(hour.length() == 0){
            hour = "00";
        }
        if(hour.length() == 1){
            hour = "0"+hour;
        }
        if(min.length() == 0){
            min = "00";
        }
        if(min.length() == 1){
            min = "0"+min;
        }
    time = hour +":"+ min;
        serviceIntent = new Intent(getActivity(),AlarmService.class);

        serviceIntent.putExtra("TIME", MainActivity.date + "," + time);
       getActivity().startService(serviceIntent);
    }

    @Override
    public void onCancel(@NonNull DialogInterface dialog) {
        super.onCancel(dialog);

    }
}